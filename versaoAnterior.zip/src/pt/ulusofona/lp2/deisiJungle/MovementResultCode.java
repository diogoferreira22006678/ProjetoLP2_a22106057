package pt.ulusofona.lp2.deisiJungle;

public enum MovementResultCode {
    INVALID_MOVEMENT,
    NO_ENERGY,
    VALID_MOVEMENT,
    CAUGHT_FOOD
}
